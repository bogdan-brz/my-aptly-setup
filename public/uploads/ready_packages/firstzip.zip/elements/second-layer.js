print("bet");
