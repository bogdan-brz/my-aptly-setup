import styles from "./AboutUs.module.css";

const AboutUs = () => {
    return <div className={styles.aboutus}>About Us Page</div>;
};

export default AboutUs;
