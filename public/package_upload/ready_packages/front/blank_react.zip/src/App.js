import styles from "./App.module.css";

function App() {
    return <div className={styles.app}>Hello World</div>;
}

export default App;
